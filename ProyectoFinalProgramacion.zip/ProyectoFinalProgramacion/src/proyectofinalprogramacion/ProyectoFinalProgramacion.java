package proyectofinalprogramacion;

import java.util.Random;
import javax.swing.JOptionPane;

public class ProyectoFinalProgramacion {

    static String resp, texto;
    static int i, j;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // FINAL FINAL FINAL FINAL

        byte opt = 0;

        JOptionPane.showMessageDialog(null, "BIENVENIDO AL TRABAJO FINAL DE PRGRAMACION 1!!! \n\n"
                + "                     Development Team: \n"
                + "                     Jose Silva \n"
                + "                     Fabricio Mora\n"
                + "                     Ignacio Mendez\n"
                + "                     Johan Areas\n"
                + "                     Christian Prado\n"
                + "                     Stephanie Solis \n\n");

        do {//inicio del menu

            opt = Byte.parseByte(JOptionPane.showInputDialog(null, "Escoja una opción del menú para ver el ejercicio: \n"
                    + "1. Lista de participaciones de las olimpiadas de China \n"
                    + "2. Descripción del cuadro mágico \n"
                    + "3. Piedra, papel y tijera \n"
                    + "4. Buscaminas \n"
                    + "5. Salir del sistema"));

            if (opt < 1 || opt > 5) {

                JOptionPane.showMessageDialog(null, "Escoja una opción válida del menu, del 1 al 5");

            } else {

                switch (opt) {

                    case 1:

                        byte opcion;
                        int participantes = 0;

                        String informacion = "";
                        int[] arreglo = new int[20];
                        String[] nombre = new String[20];
                        double[] marca1 = new double[20];
                        double[] marca2 = new double[20];
                        double[] marca3 = new double[20];
                        //Creacion del ciclo que repite todo el menu
                        do {
                            //Captura de la opcion ingresada y muestra del menu al usuario
                            opcion = Byte.parseByte(JOptionPane.showInputDialog("Ingrese la opcion que desee:"
                                    + "\n 1. Ingresar participantes"
                                    + "\n 2. Mostrar listado de datos"
                                    + "\n 3. Mostrar listado por marcas"
                                    + "\n 4. Desea volver al menu"));
                            //Menu
                            switch (opcion) {
                                case 1:
                                    //Captura de la cantidad de participantes
                                    participantes = Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos participantes desea agregar?"));
                                    //Se le asigna la cantidad de participantes ingresados al arreglo
                                    arreglo = new int[participantes];
                                    //Condicion si el usuario ingresó una cantidad válida entre 1 y 20
                                    if (participantes > 0 && participantes <= 20) {
                                        //Ciclo que recorre los arreglos, captura los datos y guarda su información
                                        for (i = 1; i <= arreglo.length; i++) {
                                            nombre[i] = JOptionPane.showInputDialog("Ingrese el nombre del participante");
                                            marca1[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la marca de 1989"));
                                            marca2[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la marca de 1990"));
                                            marca3[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la marca de 2000"));
                                        }
                                    } //Condicion en caso que el usuario no digite una cantidad válida
                                    else {
                                        JOptionPane.showMessageDialog(null, "Ingrese una cantidad entre 1 y 20 por favor");
                                    }
                                    break;

                                case 2:
                                    if (participantes == 0) {//Condicion en caso que el usuario no haya ingresado ningun dato
                                        JOptionPane.showMessageDialog(null, "Por favor ingrese datos en la primera opcion antes de ingresar a esta opcion");
                                    } else {//Condicion en caso que el usuario haya ingresado datos
                                        //Ciclo que muestra los datos de los participantes por respectivo numero de dorsal
                                        for (i = 1; i <= arreglo.length; i++) {
                                            JOptionPane.showMessageDialog(null, "Participante #" + i
                                                    + "\n Nombre del participante: " + nombre[i]
                                                    + "\n Marca de 1989: " + marca1[i]
                                                    + "\n Marca de 1990: " + marca2[i]
                                                    + "\n Marca de 2000: " + marca3[i]);
                                        }
                                    }
                                    break;

                                case 3:
                                    if (participantes == 0) {//Condicion en caso que el usuario no haya ingresado ningun dato
                                        JOptionPane.showMessageDialog(null, "Por favor ingrese datos en la primera opcion antes de ingresar a esta opcion");
                                    } else {//Condicion en caso que el usuario haya ingresado datos
                                        //Ciclo que muestra las marcas de 1991 de mayor a menor de los participantes
                                        for (i = arreglo.length; i >= 1; i--) {
                                            informacion = informacion + "\n Participante #" + i
                                                    + "\n Nombre del participante: " + nombre[i]
                                                    + "\n Marca de 2000: " + marca3[i]
                                                    + "\n Marca de 1990: " + marca2[i]
                                                    + "\n Marca de 1989: " + marca1[i] + "\n";
                                        }
                                        JOptionPane.showMessageDialog(null, "Marcas de mayor a menor \n" + informacion);
                                    }
                                    break;

                                /*case 4:
                                System.exit(0);//El salir
                                break;*/
 /*default:
                                    JOptionPane.showMessageDialog(null, "Opcion Invalida");//La opcion por defecto*/
                            }
                        } while (opcion != 4);
                        break;
                    //*******termina el primer ejercicio

                    case 2:
                        int r1,
                         r2 = 0;
                        int[][] array = new int[3][3];
                        do {
                            texto = "";
                            r1 = (int) (Math.random() * 10);// primer random donde se indica la posibilidad de que salga un cuadro magico
                            if (r1 == 2 || r1 == 3) {// condicion que dice que solo puede ser cuadro magico si sale el 2 o 3
                                r2 = (int) (Math.random() * 4);//indicara cual cuadro magico mostrara
                                //JOptionPane.showMessageDialog(null, r2);
                                switch (r2) {
                                    case 0://primer cuadro magico
                                        texto = "";
                                        texto = "| 4 | | 9 | | 2 | \n| 3 | | 5 | | 7 | \n| 8 | | 1 | | 6 | \n "
                                                + "Es un cuadro magico";
                                        break;
                                    case 1://segundo cuadro magico
                                        texto = "";
                                        texto = "| 2 | | 9 | | 4 | \n| 7 | | 5 | | 3 | \n| 6 | | 1 | | 8 | \n "
                                                + "Es un cuadro magico";
                                        break;
                                    case 2://tercer cuadro magico
                                        texto = "";
                                        texto = "| 6 | | 1 | | 8 | \n| 7 | | 5 | | 3 | \n| 2 | | 9 | | 4 | \n "
                                                + "Es un cuadro magico";
                                        break;
                                    case 3://cuarto cuadro magico
                                        texto = "";
                                        texto = "| 8 | | 1 | | 6 | \n| 3 | | 5 | | 7 | \n| 4 | | 9 | | 2 | \n "
                                                + "Es un cuadro magico";
                                        break;
                                }
                                JOptionPane.showMessageDialog(null, texto);// imprime el cuadro magico 
                            } else {// entrara si no sole un 2 o 3 en el random
                                texto = "";
                                for (i = 0; i < 3; i++) {
                                    for (j = 0; j < 3; j++) {
                                        array[i][j] = (int) (Math.random() * 10);//le asigna un numero random al array para luego imoprimirlo
                                        texto = texto + " | " + array[i][j] + " | ";//concatena el array con el numero asignado
                                    }
                                    texto = texto + "\n";//espacio entre lineas
                                }
                                JOptionPane.showMessageDialog(null, texto + " No es cuadro magico.");//imprime el cuadro magico
                            }
                            // break;
                            resp = JOptionPane.showInputDialog("Desea intentarlo de nuevo? (S/N)");//Opcion para que el usuario si desea iniciar otra vez o volver.
                            resp = resp.toUpperCase();//es para que la letra que ingrese siempre sea mayuscula
                        } while (resp.equals("S"));
                        //*****termina el segundo ejercicio
                        break;

                    case 3:

                        int piedra,
                         papel,
                         tijera,
                         player,
                         bot,
                         jugadas,
                         bot_score,
                         player_score,
                         contmar;
                        do {
                            piedra = 1;
                            papel = 2;
                            tijera = 3;
                            bot_score = 0;
                            player_score = 0;
                            contmar = 0;

                            String[] score = new String[contmar + 1];
                            for (i = 0; i < 3; i++) {//se ingresa todo la logica en un for por que se hara al mejor de 3 partidas
                                player = 0;
                                player = Integer.parseInt(JOptionPane.showInputDialog("Seleccione una de "
                                        + "las siguientes opciones para su jugada:\n"
                                        + "Piedra = 1\n"
                                        + "Papel = 2\n"
                                        + "Tijera = 3\n"));
                                if (player >= 4) {//se agregue una opcion para que el usuario ingrese un opcion
                                    JOptionPane.showMessageDialog(null, "Ingrese un opcion entre 1 y 3 ");
                                } else {

                                    int bot_random = new Random().nextInt(4); //genera un numero random entre 1 y 3

                                    switch (bot_random) {//imprime la seleccion del bot segun el random

                                        case 1:
                                            JOptionPane.showMessageDialog(null, "La computadora selecciono Piedra");
                                            break;
                                        case 2:
                                            JOptionPane.showMessageDialog(null, "La computadora selecciono Papel");
                                            break;
                                        case 3:
                                            JOptionPane.showMessageDialog(null, "La computadora selecciono Tijera");
                                            break;
                                    }//termina el switch
                                    bot = bot_random;
//empiezan los if de draw****
                                    if (player == 1 && bot == 1 || player == 2 && bot == 2 || player == 3 && bot == 3) {
                                        JOptionPane.showMessageDialog(null, "Es un EMPATE");
                                    } //empiezan los if de gane del bot****
                                    else if (player == 1 && bot == 2) {

                                        JOptionPane.showMessageDialog(null, "PAPEL le gana a PIEDRA! \n"
                                                + "Ha ganado la COMPUTADORA !");
                                        bot_score++;

                                    } else if (player == 2 && bot == 3) {

                                        JOptionPane.showMessageDialog(null, "TIJERA le gana a PAPEL! \n"
                                                + "Ha ganado la COMPUTADORA !");
                                        bot_score++;

                                    } else if (player == 3 && bot == 1) {

                                        JOptionPane.showMessageDialog(null, "PIEDRA le gana a TIJERA! \n"
                                                + "Ha ganado la COMPUTADORA !");
                                        bot_score++;

//empiezan los if de gane del jugador****
                                    } else if (bot == 1 && player == 2) {

                                        JOptionPane.showMessageDialog(null, "PAPEL le gana a PIEDRA! \n"
                                                + "Ha ganado el JUGADOR !");
                                        player_score++;
                                    } else if (bot == 2 && player == 3) {

                                        JOptionPane.showMessageDialog(null, "TIJERA le gana a PAPEL! \n"
                                                + "Ha ganado el JUGADOR !");
                                        player_score++;
                                    } else if (bot == 3 && player == 1) {

                                        JOptionPane.showMessageDialog(null, "PIEDRA le gana a TIJERA! \n"
                                                + "Ha ganado el JUGADOR !");
                                        player_score++;
                                    }

                                    if (player_score == 2) {//el contador es la comparativa del ganador, si el un jugador obtuvo 2 punto el juego termina
                                        i++;

                                    }
                                    if (bot_score == 2) {
                                        i++;

                                    }

                                    //modifique los mensajes de victoria cada jugador
                                }
                            }
                            if (bot_score == player_score) {
                                JOptionPane.showMessageDialog(null, "Es un EMPATE de los jugadores! \n");
                            } else if (player_score > bot_score) {//el contador es la comparativa del ganador
                                JOptionPane.showMessageDialog(null, "El JUGADOR ha ganado! \n");

                            } else if (player_score < bot_score) {
                                JOptionPane.showMessageDialog(null, "La COMPUTADORA ha ganado! \n");
                            }

                            resp = JOptionPane.showInputDialog("Desea ingresar otra opcion? (S/N)");//Opcion para que el usuario si desea iniciar otra vez o volver.
                            resp = resp.toUpperCase();//es para que la letra que ingrese siempre sea mayuscula
                        } while (resp.equals("S"));

                        break;

                    case 4:
                        texto = "";
                        texto = JOptionPane.showInputDialog("Bienvenido al buscaminas!! \n El juego consiste en intentar liberar las celdas sin "
                                + "pisar una mina. \n El juego pondra una cantidad de minas de forma aleatoria, podras sobrevivir a la prueba?\n Escriba en el cuadro -> ACEPTO o SI <- !!!"
                                + "Si no acepta, regresara al menu principal");

                        texto = texto.toUpperCase();
                        if (texto.equals("ACEPTO") || texto.equals("(ACEPTO)")) {
                            do {
                                int minas[][] = new int[8][8]; //crea 2d array (tabla de 9*9), 
                                //para colocar las minas
                                Object usuario[][] = new Object[8][8]; // crea 2d array, este es
                                //el que se le muestra al usuario
                                Object[] lista_num = new Object[11];//lista de objectos para mostrar 
                                //al jugador espacios vacios o minas
                                lista_num[0] = "|  X |"; // esto es una mina
                                lista_num[1] = "|_,_|"; // esto es un espacion vacio ya seleccionado
                                lista_num[2] = "|  1 |"; //cantidad de minas alrededor
                                lista_num[3] = "|  2 |"; //cantidad de minas alrededor
                                lista_num[4] = "|  3 |"; //cantidad de minas alrededor
                                lista_num[5] = "|  4 |"; //cantidad de minas alrededor
                                lista_num[6] = "|  5 |"; //cantidad de minas alrededor
                                lista_num[7] = "|  6 |"; //cantidad de minas alrededor
                                lista_num[8] = "|  7 |"; //cantidad de minas alrededor
                                lista_num[9] = "|  8 |"; //cantidad de minas alrededor
                                lista_num[10] = "";
                                //*************************************Se declaran los arrays que se utilizaran
                                int posf, posc, contador, contador_minas, contwin;
                                contador = 0;//cantidad de minas
                                posf = 0; //variables ingresadas por el usuario***
                                posc = 0; //variables ingresadas por el usuario***
                                contador_minas = 0; // contador de minas alrededor de un cuadro
                                contwin = 0;
                                texto = ""; //imprime el valor del array equivalente al tablero de juego
                                //terminan las variables***
                                //aca inicia todo el juego*****
                                for (i = 0; i < 8; i++) {//crea el recorrido del que array genera las minas
                                    for (j = 0; j < 8; j++) {
                                        minas[i][j] = new Random().nextInt(10); //genera un numero aleatorio
                                        //entre 0 y 10
                                        if (minas[i][j] == 8 || minas[i][j] == 9) {
                                            minas[i][j] = 11; // los numeros iguales a 11 se convierten en minas, 
                                            //el numero de minas es aleatorio segun la cantidad de 8 y 9
                                            contador++;//cuenta el numero de minas generado por el random
                                        }
                                        //texto = texto + "   " + minas[i][j];//**** este no se va a imprimir 
                                    }//termina segundo for
                                    //texto = texto + "\n"; //**** este no se va a imprimir
                                }//termina primer for
                                for (i = 0; i < usuario.length; i++) {//este es el array que se le muestra al usuario/juego inicial
                                    for (j = 0; j < usuario.length; j++) {
                                        usuario[i][j] = "|" + i + "," + j + "|";
                                        texto = texto + "   " + usuario[i][j]; //crea un espacio entre cada valor del array
                                    }//termina segundo for
                                    texto = texto + "\n"; // crea un grid de todos los valores del array en filas distintas
                                }//termina primer for
                                //JOptionPane.showMessageDialog(null, "\n |Filas, Columas|\n" + texto + "\n Cantidad de minas en juego: " + contador);// Es de prueba
                                do {
                                    contwin = 64 - contador;//conteo de numeros, cuando llega a 0, se gana el juego
                                    posf = Integer.parseInt(JOptionPane.showInputDialog("|Filas, Columas|\n" + texto + "\n Cantidad de "
                                            + "minas en juego: " + contador
                                            + "\n" + "Ingrese la posición que desea validar para la fila entre (0 y 7)"));//jugador ingresa el numero del array que corresponde a 
                                    //la fila
                                    posc = Integer.parseInt(JOptionPane.showInputDialog("|Filas, Columas|\n" + texto + "\n Cantidad de "
                                            + "minas en juego: " + contador
                                            + "\n"
                                            + "Fila: " + posf + "\n"
                                            + "Ingrese la posición que desea validar para la columna entre (0 y 7)"));//jugador ingresa el numero del array que corresponde 
                                    //a la columna
                                    //compara los valores seleccionados por el usuario con el array de minas
                                    if (minas[posf][posc] == 11) {
                                        usuario[posf][posc] = "|X|";
                                        JOptionPane.showMessageDialog(null, "Has perdido");//si el valor seleccionado es igual a 11, 
                                        //entonces selecciono una mina y perdio
                                        texto = "";
                                        for (i = 0; i < minas.length; i++) {
                                            for (j = 0; j < minas.length; j++) {
                                                if (minas[i][j] != 11) {
                                                    usuario[i][j] = lista_num[1];//si el espacio seleccionado por el usuario es distinto a 11 entonces no es una mina
                                                    // y continua en el juego

                                                } else {
                                                    usuario[i][j] = lista_num[0];//muestra los espacios del tablero que eran minas, todas las minas
                                                }
                                                texto = texto + "   " + usuario[i][j];
                                            }
                                            texto = texto + "\n";
                                        }
                                        JOptionPane.showMessageDialog(null, "|Filas, Columas|\n" + texto + "\n Cantidad de minas en juego: " + contador);
                                    }//termina if
                                    if (minas[posf][posc] != 11) {//descartar que el espacio sea una mina
                                        contador_minas = 0;
                                        if (posf + 1 <= 7 && posc <= 7) {//chequea el rango maximo del array
                                            if (posf + 1 >= 0 && posc >= 0) {//chequea una pocision de abajo, pocision 2
                                                if (minas[posf + 1][posc] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf + 1 <= 7 && posc + 1 <= 7) {//chequea el rango maximo del array
                                            if (posf + 1 >= 0 && posc + 1 >= 0) {//chequea la pocision diagonal abajo y derecha, pocision 3
                                                if (minas[posf + 1][posc + 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf <= 7 && posc + 1 <= 7) {//chequea el rango maximo del array
                                            if (posf >= 0 && posc + 1 >= 0) {//chequeda la pocision derecha, pocision 6
                                                if (minas[posf][posc + 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf - 1 <= 7 && posc + 1 <= 7) {//chequea el rango maximo del array
                                            if (posf - 1 >= 0 && posc + 1 >= 0) {//chequeda pocision diagonal derecha arriba, pocision 9
                                                if (minas[posf - 1][posc + 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf - 1 <= 7 && posc <= 7) {//chequea el rango maximo del array
                                            if (posf - 1 >= 0 && posc >= 0) {//chequea pocision arriba, pocision 8
                                                if (minas[posf - 1][posc] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf - 1 <= 7 && posc - 1 <= 7) {//chequea el rango maximo del array
                                            if (posf - 1 >= 0 && posc - 1 >= 0) {//chequea pocision diagonal arriba izquierda, pocision 7
                                                if (minas[posf - 1][posc - 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf <= 7 && posc - 1 <= 7) {//chequea el rango maximo del array
                                            if (posf >= 0 && posc - 1 >= 0) {//chequea pocision izquierda, pocision 4
                                                if (minas[posf][posc - 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        if (posf + 1 <= 7 && posc - 1 <= 7) {//chequea el rango maximo del array
                                            if (posf + 1 >= 0 && posc - 1 >= 0) {//chequea pocision diagonal izquierda abajo, pocision 1
                                                if (minas[posf + 1][posc - 1] == 11) {//se mueve a la siguiente fila
                                                    contador_minas++;
                                                }
                                            }
                                        }
                                        switch (contador_minas) {
                                            case 0:
                                                usuario[posf][posc] = lista_num[1];
                                                contwin--;
                                                break;
                                            case 1:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[2];
                                                contwin--;
                                                break;
                                            case 2:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[3];
                                                contwin--;
                                                break;
                                            case 3:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[4];
                                                contwin--;
                                                break;
                                            case 4:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[5];
                                                contwin--;
                                                break;
                                            case 5:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[6];
                                                contwin--;
                                                break;
                                            case 6:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[7];
                                                contwin--;
                                                break;
                                            case 7:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[8];
                                                contwin--;
                                                break;
                                            case 8:
                                                usuario[posf][posc] = "";
                                                usuario[posf][posc] = lista_num[9];
                                                contwin--;
                                                break;
                                        }
                                        texto = "";//limpia el texto para volverlo a imprimir con los cambios 
                                        for (i = 0; i < minas.length; i++) {//para modificar el cuadro que se muestra al usuario
                                            for (j = 0; j < minas.length; j++) {
                                                texto = texto + "   " + usuario[i][j];
                                            }
                                            texto = texto + "\n";
                                        }
                                        contador_minas = 0;
                                    }//if principal, no borrar
                                    if (contwin == 0) {// cuando el contador llegue a cero, gana el juego
                                        texto = "";//limpia el texto para mostra el juego completo
                                        for (i = 0; i < 8; i++) {
                                            for (j = 0; j < 8; j++) {
                                                if (minas[i][j] == 11) {
                                                    usuario[i][j] = "|X|";
                                                }
                                                texto = texto + "   " + usuario[i][j];
                                            }
                                            texto = texto + "\n";
                                        }
                                        JOptionPane.showMessageDialog(null, "HA GANADO EL JUEGO" + texto);
                                    }
                                } while (minas[posf][posc] != 11 || contwin == 0);//la condicion funciona para terminar el juego hasta que explote una mina o lo complete
                                resp = JOptionPane.showInputDialog("Desea jugar de nuevo? (S/N)");//Opcion para que el usuario si desea iniciar otra vez o volver.
                                resp = resp.toUpperCase();//es para que la letra que ingrese siempre sea mayuscula
                            } while (resp.equals("S"));
                        }
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(null, "Gracias por usar nuestros programas!  \n\n\n\n\n\n");
                        System.exit(0);
                }

            }

        } while (opt != 5);

    }

}
